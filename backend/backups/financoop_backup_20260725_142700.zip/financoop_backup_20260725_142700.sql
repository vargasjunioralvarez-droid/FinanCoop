--
-- PostgreSQL database dump
--

\restrict HI67NkVabyTGCIoEDQbA2K7tbTcZbumrEbuaJ8C6NZftb9jv1bdbVWhbRWus4bS

-- Dumped from database version 13.23
-- Dumped by pg_dump version 13.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auditoria (
    id integer NOT NULL,
    usuario_id integer,
    usuario_nombre character varying(100),
    usuario_rol character varying(50),
    accion character varying(50) NOT NULL,
    tabla character varying(50),
    registro_id integer,
    datos_antes json,
    datos_despues json,
    detalles text,
    ip character varying(45),
    user_agent character varying(255),
    endpoint character varying(255),
    metodo_http character varying(10),
    fecha timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auditoria OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auditoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auditoria_id_seq OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auditoria_id_seq OWNED BY public.auditoria.id;


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    cedula character varying(20) NOT NULL,
    telefono character varying(20),
    email character varying(200),
    direccion text,
    referencia_nombre character varying(200),
    referencia_telefono character varying(20),
    referencia_parentesco character varying(100),
    url_cedula character varying(500),
    score integer,
    nivel character varying(50),
    total_compras integer,
    total_monto_comprado_usd double precision,
    cuotas_pagadas_tiempo integer,
    cuotas_con_mora integer,
    pin character varying(10),
    pin_hash character varying(255),
    token_app character varying(500),
    estado character varying(20),
    tienda_id integer,
    ultimo_acceso timestamp with time zone,
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone
);


ALTER TABLE public.clientes OWNER TO postgres;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clientes_id_seq OWNER TO postgres;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: configuracion_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.configuracion_pago (
    id integer NOT NULL,
    banco_pago_movil character varying(100),
    telefono_pago_movil character varying(20),
    cedula_pago_movil character varying(20),
    banco_transferencia character varying(100),
    cuenta_transferencia character varying(50),
    correo_zelle character varying(200),
    correo_binance character varying(200),
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone
);


ALTER TABLE public.configuracion_pago OWNER TO postgres;

--
-- Name: configuracion_pago_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.configuracion_pago_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuracion_pago_id_seq OWNER TO postgres;

--
-- Name: configuracion_pago_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.configuracion_pago_id_seq OWNED BY public.configuracion_pago.id;


--
-- Name: cuotas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cuotas (
    id integer NOT NULL,
    financiamiento_id integer NOT NULL,
    numero integer NOT NULL,
    monto_base_bs double precision NOT NULL,
    monto_base_usd double precision NOT NULL,
    monto_interes_mora_bs double precision,
    monto_interes_mora_usd double precision,
    monto_total_bs double precision NOT NULL,
    monto_total_usd double precision NOT NULL,
    monto double precision,
    monto_usd double precision,
    mora double precision,
    mora_usd double precision,
    monto_pagado double precision,
    fecha_vencimiento timestamp with time zone NOT NULL,
    fecha_pago timestamp with time zone,
    estado character varying(50),
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone
);


ALTER TABLE public.cuotas OWNER TO postgres;

--
-- Name: cuotas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cuotas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cuotas_id_seq OWNER TO postgres;

--
-- Name: cuotas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cuotas_id_seq OWNED BY public.cuotas.id;


--
-- Name: financiamientos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financiamientos (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    tienda_id integer,
    codigo character varying(20),
    descripcion text,
    url_factura character varying(500),
    numero_factura character varying(100),
    monto_total_bs double precision NOT NULL,
    monto_entrada_bs double precision NOT NULL,
    monto_financia_bs double precision NOT NULL,
    monto_cuota_bs double precision NOT NULL,
    monto_total_usd double precision NOT NULL,
    monto_entrada_usd double precision NOT NULL,
    monto_financia_usd double precision NOT NULL,
    monto_cuota_usd double precision NOT NULL,
    tasa_aplicada double precision NOT NULL,
    nivel_aplicado character varying(50),
    cuotas_solicitadas integer NOT NULL,
    cuotas_aprobadas integer NOT NULL,
    requiere_aprobacion boolean,
    aprobado_por character varying(50),
    entrada_pct double precision NOT NULL,
    financia_pct double precision NOT NULL,
    fecha_primera_cuota timestamp with time zone,
    fecha_completado timestamp with time zone,
    monto double precision NOT NULL,
    monto_usd double precision NOT NULL,
    tasa_dolar double precision NOT NULL,
    plazo_meses integer NOT NULL,
    entrada double precision NOT NULL,
    entrada_usd double precision NOT NULL,
    financia double precision NOT NULL,
    financia_usd double precision NOT NULL,
    cuota_mensual double precision NOT NULL,
    cuota_mensual_usd double precision NOT NULL,
    total_pagar double precision NOT NULL,
    total_pagar_usd double precision NOT NULL,
    estado character varying(50),
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone
);


ALTER TABLE public.financiamientos OWNER TO postgres;

--
-- Name: financiamientos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.financiamientos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.financiamientos_id_seq OWNER TO postgres;

--
-- Name: financiamientos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.financiamientos_id_seq OWNED BY public.financiamientos.id;


--
-- Name: historial_estados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.historial_estados (
    id integer NOT NULL,
    entidad_tipo character varying(50) NOT NULL,
    entidad_id integer NOT NULL,
    estado_anterior character varying(50),
    estado_nuevo character varying(50) NOT NULL,
    cambiado_por character varying(200),
    motivo text,
    ip_origen character varying(50),
    cliente_id integer,
    fecha timestamp with time zone DEFAULT now()
);


ALTER TABLE public.historial_estados OWNER TO postgres;

--
-- Name: historial_estados_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.historial_estados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.historial_estados_id_seq OWNER TO postgres;

--
-- Name: historial_estados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.historial_estados_id_seq OWNED BY public.historial_estados.id;


--
-- Name: logs_conciliacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.logs_conciliacion (
    id integer NOT NULL,
    referencia character varying(100),
    monto_banco double precision,
    monto_reportado double precision,
    estado character varying(50),
    respuesta_banco text,
    fecha timestamp with time zone DEFAULT now()
);


ALTER TABLE public.logs_conciliacion OWNER TO postgres;

--
-- Name: logs_conciliacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.logs_conciliacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_conciliacion_id_seq OWNER TO postgres;

--
-- Name: logs_conciliacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.logs_conciliacion_id_seq OWNED BY public.logs_conciliacion.id;


--
-- Name: niveles_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.niveles_config (
    id integer NOT NULL,
    nivel character varying(50) NOT NULL,
    min_score integer NOT NULL,
    max_score integer NOT NULL,
    monto_max_usd double precision NOT NULL,
    entrada_pct double precision NOT NULL,
    financia_pct double precision NOT NULL,
    cuotas_base integer NOT NULL,
    cuotas_max integer NOT NULL,
    mora_diaria double precision NOT NULL,
    aprobacion_extra boolean,
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone
);


ALTER TABLE public.niveles_config OWNER TO postgres;

--
-- Name: niveles_config_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.niveles_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.niveles_config_id_seq OWNER TO postgres;

--
-- Name: niveles_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.niveles_config_id_seq OWNED BY public.niveles_config.id;


--
-- Name: pagos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pagos (
    id integer NOT NULL,
    financiamiento_id integer NOT NULL,
    cuota_id integer,
    monto double precision NOT NULL,
    monto_usd double precision NOT NULL,
    metodo character varying(50) NOT NULL,
    referencia character varying(100),
    monto_reportado_bs double precision,
    monto_confirmado_bs double precision,
    monto_original_bs double precision,
    banco_origen character varying(100),
    telefono_pago character varying(20),
    cedula_pago character varying(20),
    comprobante character varying(500),
    modo_pago character varying(50),
    cuotas_incluidas text,
    pago_padre_id integer,
    estado character varying(50),
    fecha_reporte timestamp with time zone DEFAULT now(),
    fecha_confirmacion timestamp with time zone,
    fecha_rechazo timestamp with time zone,
    conciliado_por character varying(100),
    rechazado_por character varying(100),
    creado_en timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pagos OWNER TO postgres;

--
-- Name: pagos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pagos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pagos_id_seq OWNER TO postgres;

--
-- Name: pagos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pagos_id_seq OWNED BY public.pagos.id;


--
-- Name: tasa_dolar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasa_dolar (
    id integer NOT NULL,
    tasa double precision NOT NULL,
    fuente character varying(100),
    actualizado_por character varying(100),
    fecha timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tasa_dolar OWNER TO postgres;

--
-- Name: tasa_dolar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasa_dolar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasa_dolar_id_seq OWNER TO postgres;

--
-- Name: tasa_dolar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasa_dolar_id_seq OWNED BY public.tasa_dolar.id;


--
-- Name: tiendas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tiendas (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    codigo character varying(20) NOT NULL,
    direccion text,
    telefono character varying(20),
    activo boolean,
    creado_en timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tiendas OWNER TO postgres;

--
-- Name: tiendas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tiendas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tiendas_id_seq OWNER TO postgres;

--
-- Name: tiendas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tiendas_id_seq OWNED BY public.tiendas.id;


--
-- Name: token_blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_blacklist (
    id integer NOT NULL,
    jti character varying(255) NOT NULL,
    expira_en timestamp with time zone NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


ALTER TABLE public.token_blacklist OWNER TO postgres;

--
-- Name: token_blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.token_blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_blacklist_id_seq OWNER TO postgres;

--
-- Name: token_blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.token_blacklist_id_seq OWNED BY public.token_blacklist.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    nombre character varying(200),
    email character varying(200),
    rol character varying(50),
    activo boolean,
    tienda_id integer,
    creado_por character varying(100),
    ultimo_acceso timestamp with time zone,
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: auditoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria ALTER COLUMN id SET DEFAULT nextval('public.auditoria_id_seq'::regclass);


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: configuracion_pago id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.configuracion_pago ALTER COLUMN id SET DEFAULT nextval('public.configuracion_pago_id_seq'::regclass);


--
-- Name: cuotas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuotas ALTER COLUMN id SET DEFAULT nextval('public.cuotas_id_seq'::regclass);


--
-- Name: financiamientos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financiamientos ALTER COLUMN id SET DEFAULT nextval('public.financiamientos_id_seq'::regclass);


--
-- Name: historial_estados id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.historial_estados ALTER COLUMN id SET DEFAULT nextval('public.historial_estados_id_seq'::regclass);


--
-- Name: logs_conciliacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs_conciliacion ALTER COLUMN id SET DEFAULT nextval('public.logs_conciliacion_id_seq'::regclass);


--
-- Name: niveles_config id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveles_config ALTER COLUMN id SET DEFAULT nextval('public.niveles_config_id_seq'::regclass);


--
-- Name: pagos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos ALTER COLUMN id SET DEFAULT nextval('public.pagos_id_seq'::regclass);


--
-- Name: tasa_dolar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasa_dolar ALTER COLUMN id SET DEFAULT nextval('public.tasa_dolar_id_seq'::regclass);


--
-- Name: tiendas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tiendas ALTER COLUMN id SET DEFAULT nextval('public.tiendas_id_seq'::regclass);


--
-- Name: token_blacklist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist ALTER COLUMN id SET DEFAULT nextval('public.token_blacklist_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auditoria (id, usuario_id, usuario_nombre, usuario_rol, accion, tabla, registro_id, datos_antes, datos_despues, detalles, ip, user_agent, endpoint, metodo_http, fecha) FROM stdin;
1	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:02:54.989183+00
2	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:03:28.696838+00
3	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:06:07.343273+00
4	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:07:18.093087+00
5	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:07:40.22738+00
6	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:08:24.933249+00
7	\N	admin	\N	LOGIN	\N	\N	null	null	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 02:10:20.305573+00
8	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 18:24:02.726773+00
9	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 18:24:13.319998+00
10	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 18:24:46.880909+00
11	\N	desconocido	\N	LOGIN_FAILED	\N	\N	null	null	Intento fallido: 401: Credenciales incorrectas	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 18:25:52.427231+00
12	\N	admin	\N	LOGIN	\N	\N	null	null	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	/api/v1/auth/login-json	POST	2026-07-25 18:26:31.161026+00
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientes (id, nombre, cedula, telefono, email, direccion, referencia_nombre, referencia_telefono, referencia_parentesco, url_cedula, score, nivel, total_compras, total_monto_comprado_usd, cuotas_pagadas_tiempo, cuotas_con_mora, pin, pin_hash, token_app, estado, tienda_id, ultimo_acceso, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: configuracion_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.configuracion_pago (id, banco_pago_movil, telefono_pago_movil, cedula_pago_movil, banco_transferencia, cuenta_transferencia, correo_zelle, correo_binance, creado_en, actualizado_en) FROM stdin;
1	Banco de Venezuela	04121234567	V12345678	Banco Mercantil	01051234567890123456	\N	\N	2026-07-25 01:59:00.670613+00	\N
\.


--
-- Data for Name: cuotas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cuotas (id, financiamiento_id, numero, monto_base_bs, monto_base_usd, monto_interes_mora_bs, monto_interes_mora_usd, monto_total_bs, monto_total_usd, monto, monto_usd, mora, mora_usd, monto_pagado, fecha_vencimiento, fecha_pago, estado, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: financiamientos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financiamientos (id, cliente_id, tienda_id, codigo, descripcion, url_factura, numero_factura, monto_total_bs, monto_entrada_bs, monto_financia_bs, monto_cuota_bs, monto_total_usd, monto_entrada_usd, monto_financia_usd, monto_cuota_usd, tasa_aplicada, nivel_aplicado, cuotas_solicitadas, cuotas_aprobadas, requiere_aprobacion, aprobado_por, entrada_pct, financia_pct, fecha_primera_cuota, fecha_completado, monto, monto_usd, tasa_dolar, plazo_meses, entrada, entrada_usd, financia, financia_usd, cuota_mensual, cuota_mensual_usd, total_pagar, total_pagar_usd, estado, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: historial_estados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.historial_estados (id, entidad_tipo, entidad_id, estado_anterior, estado_nuevo, cambiado_por, motivo, ip_origen, cliente_id, fecha) FROM stdin;
\.


--
-- Data for Name: logs_conciliacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.logs_conciliacion (id, referencia, monto_banco, monto_reportado, estado, respuesta_banco, fecha) FROM stdin;
\.


--
-- Data for Name: niveles_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.niveles_config (id, nivel, min_score, max_score, monto_max_usd, entrada_pct, financia_pct, cuotas_base, cuotas_max, mora_diaria, aprobacion_extra, creado_en, actualizado_en) FROM stdin;
1	nuevo	0	99	100	30	70	3	6	2	f	2026-07-25 01:59:00.670613+00	\N
2	bronce	100	199	200	25	75	4	8	1.5	f	2026-07-25 01:59:00.670613+00	\N
3	plata	200	299	400	20	80	4	10	1	f	2026-07-25 01:59:00.670613+00	\N
4	oro	300	399	800	15	85	3	12	1	t	2026-07-25 01:59:00.670613+00	\N
5	platino	400	9999	1500	10	90	3	15	0.5	t	2026-07-25 01:59:00.670613+00	\N
\.


--
-- Data for Name: pagos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pagos (id, financiamiento_id, cuota_id, monto, monto_usd, metodo, referencia, monto_reportado_bs, monto_confirmado_bs, monto_original_bs, banco_origen, telefono_pago, cedula_pago, comprobante, modo_pago, cuotas_incluidas, pago_padre_id, estado, fecha_reporte, fecha_confirmacion, fecha_rechazo, conciliado_por, rechazado_por, creado_en) FROM stdin;
\.


--
-- Data for Name: tasa_dolar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasa_dolar (id, tasa, fuente, actualizado_por, fecha) FROM stdin;
1	40	manual	\N	2026-07-25 01:59:00.670613+00
\.


--
-- Data for Name: tiendas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tiendas (id, nombre, codigo, direccion, telefono, activo, creado_en) FROM stdin;
\.


--
-- Data for Name: token_blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_blacklist (id, jti, expira_en, creado_en) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, username, password, nombre, email, rol, activo, tienda_id, creado_por, ultimo_acceso, creado_en, actualizado_en) FROM stdin;
1	admin_central	$2b$12$BNJYQ510k6A3eqsnTZKu1edcAL7WoolBbcrLe17VRESkl1VniUgp6	Administrador Central	admin@financoop.com	admin_central	t	\N	system	2026-07-25 18:26:31.141828+00	2026-07-25 02:02:09.89864+00	2026-07-25 18:26:30.793453+00
\.


--
-- Name: auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auditoria_id_seq', 12, true);


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clientes_id_seq', 1, false);


--
-- Name: configuracion_pago_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.configuracion_pago_id_seq', 1, true);


--
-- Name: cuotas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cuotas_id_seq', 1, false);


--
-- Name: financiamientos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.financiamientos_id_seq', 1, false);


--
-- Name: historial_estados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.historial_estados_id_seq', 1, false);


--
-- Name: logs_conciliacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.logs_conciliacion_id_seq', 1, false);


--
-- Name: niveles_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.niveles_config_id_seq', 5, true);


--
-- Name: pagos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pagos_id_seq', 1, false);


--
-- Name: tasa_dolar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasa_dolar_id_seq', 1, true);


--
-- Name: tiendas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tiendas_id_seq', 1, false);


--
-- Name: token_blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.token_blacklist_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, true);


--
-- Name: auditoria auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_cedula_key UNIQUE (cedula);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: configuracion_pago configuracion_pago_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.configuracion_pago
    ADD CONSTRAINT configuracion_pago_pkey PRIMARY KEY (id);


--
-- Name: cuotas cuotas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuotas
    ADD CONSTRAINT cuotas_pkey PRIMARY KEY (id);


--
-- Name: financiamientos financiamientos_codigo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financiamientos
    ADD CONSTRAINT financiamientos_codigo_key UNIQUE (codigo);


--
-- Name: financiamientos financiamientos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financiamientos
    ADD CONSTRAINT financiamientos_pkey PRIMARY KEY (id);


--
-- Name: historial_estados historial_estados_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.historial_estados
    ADD CONSTRAINT historial_estados_pkey PRIMARY KEY (id);


--
-- Name: logs_conciliacion logs_conciliacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.logs_conciliacion
    ADD CONSTRAINT logs_conciliacion_pkey PRIMARY KEY (id);


--
-- Name: niveles_config niveles_config_nivel_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveles_config
    ADD CONSTRAINT niveles_config_nivel_key UNIQUE (nivel);


--
-- Name: niveles_config niveles_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.niveles_config
    ADD CONSTRAINT niveles_config_pkey PRIMARY KEY (id);


--
-- Name: pagos pagos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY (id);


--
-- Name: tasa_dolar tasa_dolar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasa_dolar
    ADD CONSTRAINT tasa_dolar_pkey PRIMARY KEY (id);


--
-- Name: tiendas tiendas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tiendas
    ADD CONSTRAINT tiendas_pkey PRIMARY KEY (id);


--
-- Name: token_blacklist token_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist
    ADD CONSTRAINT token_blacklist_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: idx_auditoria_accion; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auditoria_accion ON public.auditoria USING btree (accion);


--
-- Name: idx_auditoria_fecha; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auditoria_fecha ON public.auditoria USING btree (fecha);


--
-- Name: idx_auditoria_tabla_registro; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auditoria_tabla_registro ON public.auditoria USING btree (tabla, registro_id);


--
-- Name: idx_auditoria_usuario; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auditoria_usuario ON public.auditoria USING btree (usuario_id);


--
-- Name: ix_auditoria_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_auditoria_id ON public.auditoria USING btree (id);


--
-- Name: ix_clientes_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clientes_id ON public.clientes USING btree (id);


--
-- Name: ix_clientes_tienda_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_clientes_tienda_id ON public.clientes USING btree (tienda_id);


--
-- Name: ix_configuracion_pago_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_configuracion_pago_id ON public.configuracion_pago USING btree (id);


--
-- Name: ix_cuotas_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_cuotas_id ON public.cuotas USING btree (id);


--
-- Name: ix_financiamientos_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_financiamientos_id ON public.financiamientos USING btree (id);


--
-- Name: ix_financiamientos_tienda_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_financiamientos_tienda_id ON public.financiamientos USING btree (tienda_id);


--
-- Name: ix_historial_estados_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_historial_estados_id ON public.historial_estados USING btree (id);


--
-- Name: ix_logs_conciliacion_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_logs_conciliacion_id ON public.logs_conciliacion USING btree (id);


--
-- Name: ix_niveles_config_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_niveles_config_id ON public.niveles_config USING btree (id);


--
-- Name: ix_pagos_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_pagos_id ON public.pagos USING btree (id);


--
-- Name: ix_tasa_dolar_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasa_dolar_id ON public.tasa_dolar USING btree (id);


--
-- Name: ix_tiendas_codigo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_tiendas_codigo ON public.tiendas USING btree (codigo);


--
-- Name: ix_tiendas_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tiendas_id ON public.tiendas USING btree (id);


--
-- Name: ix_token_blacklist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_token_blacklist_id ON public.token_blacklist USING btree (id);


--
-- Name: ix_token_blacklist_jti; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_token_blacklist_jti ON public.token_blacklist USING btree (jti);


--
-- Name: ix_usuarios_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_usuarios_id ON public.usuarios USING btree (id);


--
-- Name: ix_usuarios_tienda_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_usuarios_tienda_id ON public.usuarios USING btree (tienda_id);


--
-- Name: ix_usuarios_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_usuarios_username ON public.usuarios USING btree (username);


--
-- Name: auditoria auditoria_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: clientes clientes_tienda_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_tienda_id_fkey FOREIGN KEY (tienda_id) REFERENCES public.tiendas(id);


--
-- Name: cuotas cuotas_financiamiento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuotas
    ADD CONSTRAINT cuotas_financiamiento_id_fkey FOREIGN KEY (financiamiento_id) REFERENCES public.financiamientos(id);


--
-- Name: financiamientos financiamientos_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financiamientos
    ADD CONSTRAINT financiamientos_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: financiamientos financiamientos_tienda_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financiamientos
    ADD CONSTRAINT financiamientos_tienda_id_fkey FOREIGN KEY (tienda_id) REFERENCES public.tiendas(id);


--
-- Name: historial_estados historial_estados_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.historial_estados
    ADD CONSTRAINT historial_estados_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: pagos pagos_cuota_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_cuota_id_fkey FOREIGN KEY (cuota_id) REFERENCES public.cuotas(id);


--
-- Name: pagos pagos_financiamiento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_financiamiento_id_fkey FOREIGN KEY (financiamiento_id) REFERENCES public.financiamientos(id);


--
-- Name: usuarios usuarios_tienda_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_tienda_id_fkey FOREIGN KEY (tienda_id) REFERENCES public.tiendas(id);


--
-- PostgreSQL database dump complete
--

\unrestrict HI67NkVabyTGCIoEDQbA2K7tbTcZbumrEbuaJ8C6NZftb9jv1bdbVWhbRWus4bS

